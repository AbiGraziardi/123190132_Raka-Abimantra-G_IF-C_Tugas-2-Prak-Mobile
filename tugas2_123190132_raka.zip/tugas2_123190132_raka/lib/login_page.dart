import 'package:flutter/material.dart';

class LoginPage extends StatefulWidget {
  const LoginPage({Key? key}) : super(key: key);

  @override
  _LoginPageState createState() => _LoginPageState();
}

class _LoginPageState extends State<LoginPage> {
  String username = "";
  String password = "";
  bool loginSuccess = true;

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        appBar: AppBar(
          title: Text('Login Page'),
        ),
        body: Column(
          children: [
            logo(),
            _username(),
            _password(),
            _loginButton(context),
            forgotPassword(),
          ],
        ),
      ),
    );
  }

  Widget logo() {
    return Container(
      child: Padding(
        padding: EdgeInsets.fromLTRB(0, 150, 0, 60),
        child: FlutterLogo(
          size: 50,
        ),
      ),
    );
  }

  Widget _username() {
    return Container(
      padding: EdgeInsets.fromLTRB(300, 8, 300, 0),
      child: TextFormField(
        enabled: true,
        onChanged: (value) {
          username = value;
        },
        decoration: InputDecoration(
          hintText: 'Masukkan Username',
          labelText: 'Username',
          contentPadding: const EdgeInsets.all(8),
          border: OutlineInputBorder(
            borderRadius: BorderRadius.all(Radius.circular(30)),
            borderSide: BorderSide(color: Colors.blue),
          ),
          enabledBorder: OutlineInputBorder(
            borderRadius: BorderRadius.all(Radius.circular(30)),
            borderSide:
            BorderSide(color: (loginSuccess) ? Colors.blue : Colors.red),
          ),
        ),
      ),
    );
  }

  Widget _password() {
    return Container(
      padding: EdgeInsets.fromLTRB(300, 8, 300, 0),
      child: TextFormField(
        enabled: true,
        onChanged: (value) {
          password = value;
        },
        obscureText: true,
        decoration: InputDecoration(
          hintText: 'Masukkan Password',
          labelText: 'Password',
          contentPadding: const EdgeInsets.all(8),
          border: OutlineInputBorder(
            borderRadius: BorderRadius.all(Radius.circular(30)),
            borderSide: BorderSide(color: Colors.blue),
          ),
          enabledBorder: OutlineInputBorder(
            borderRadius: BorderRadius.all(Radius.circular(30)),
            borderSide:
                BorderSide(color: (loginSuccess) ? Colors.blue : Colors.red),
          ),
        ),
      ),
    );
  }

  Widget _loginButton(BuildContext context) {
    return Container(
      padding: EdgeInsets.fromLTRB(300, 30, 300, 5),
      width: MediaQuery.of(context).size.width,
      child: ElevatedButton(
        style: ElevatedButton.styleFrom(
          primary: (loginSuccess) ? Colors.blue : Colors.red,
          onPrimary: Colors.white,
        ),
        onPressed: () {
          //tempat untuk menjalankan logic dari button
          String text = "";
          if (username == "Tugas2" && password == "123") {
            setState(() {
              text = 'Login Berhasil';
              loginSuccess = true;
            });
          } else {
            setState(() {
              text = 'Login Gagal';
              loginSuccess = false;
            });
          }

          SnackBar snackBar = SnackBar(
            content: Text(text),
          );
          ScaffoldMessenger.of(context).showSnackBar(snackBar);
        },
        child: const Text('Log In', style: TextStyle(fontSize: 17),),
      ),
    );
  }

  Widget forgotPassword() {
    return Container(
      child:
      TextButton(
          onPressed: () {},
          child: Text(
            "Forgot Password?",
            style: TextStyle(fontSize: 17, color: Colors.grey),
          )),
    );
  }
}
